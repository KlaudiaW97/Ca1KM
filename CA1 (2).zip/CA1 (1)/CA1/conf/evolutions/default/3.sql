# --- !Ups


insert into user (email,name,password,role) values ( 'manager1@dwp.com', 'Bob Manager', 'password', 'manager' );
insert into user (email,name,password,role) values ( 'manager2@dwp.com', 'Bob Manager', 'password', 'manager' );
insert into user (email,name,password,role) values ( 'manager3@dwp.com', 'Bob Manager', 'password', 'manager' );
insert into user (email,name,password,role) values ( 'manager4@dwp.com', 'Bob Manager', 'password', 'manager' );
insert into user (email,name,password,role) values ( 'manager5@dwp.com', 'Bob Manager', 'password', 'manager' );
insert into user (email,name,password,role) values ( 'manager6@dwp.com', 'Bob Manager', 'password', 'manager' );
insert into user (email,name,password,role) values ( 'manager7@dwp.com', 'Bob Manager', 'password', 'manager' );




insert into user (email,name,password,role) values ( 'employee1@dwp.com', 'Charlie Employee', 'password', 'employee' );
insert into user (email,name,password,role) values ( 'employee2@dwp.com', 'Charlie Employee', 'password', 'employee' );
insert into user (email,name,password,role) values ( 'employee3@dwp.com', 'Charlie Employee', 'password', 'employee' );
insert into user (email,name,password,role) values ( 'employee4@dwp.com', 'Charlie Employee', 'password', 'employee' );
insert into user (email,name,password,role) values ( 'employee5@dwp.com', 'Charlie Employee', 'password', 'employee' );
insert into user (email,name,password,role) values ( 'employee6@dwp.com', 'Charlie Employee', 'password', 'employee' );
insert into user (email,name,password,role) values ( 'employee7@dwp.com', 'Charlie Employee', 'password', 'employee' );
insert into user (email,name,password,role) values ( 'employee8@dwp.com', 'Charlie Employee', 'password', 'employee' );
insert into user (email,name,password,role) values ( 'employee9@dwp.com', 'Charlie Employee', 'password', 'employee' );
insert into user (email,name,password,role) values ( 'employee10@dwp.com','Charlie Employee', 'password', 'employee' );