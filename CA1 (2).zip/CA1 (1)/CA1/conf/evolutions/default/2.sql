# --- Sample dataset
 
# --- !Ups
 
delete from projects;
 
insert into department (id,name) values ( 1,'Customer Service' );
insert into department (id,name) values ( 2,'Finance' );
insert into department (id,name) values ( 3,'IT Support' );
insert into department (id,name) values ( 4,'Marketing' );
insert into department (id,name) values ( 5,'Human Resources' );
insert into department (id,name) values ( 6,'Sales' );
 
insert into projects (id,name,dep_Name,supervisor,due_Date) values ( 1,'Customer Experience Survey','Customer Service','Man. Bob Smith','23/03/2019' );
insert into projects (id,name,dep_Name,supervisor,due_Date) values ( 2,'2nd Floor Renovation Budget Plan','Finance','Man. Emma Freeman','16/03/2019' );
insert into projects (id,name,dep_Name,supervisor,due_Date) values ( 3,'New IT equipment','IT Support','Man. Emma Freeman','14/06/2019' );
insert into projects (id,name,dep_Name,supervisor,due_Date) values ( 4,'Monthly Spending','Finance','Man. Emma Freeman','16/03/2019' );
insert into projects (id,name,dep_Name,supervisor,due_Date) values ( 5,'Advertisement of DWP','Marketing','Man. Bob Smith','23/04/2019' );
insert into projects (id,name,dep_Name,supervisor,due_Date) values ( 6,'Open Day for Interns','Human Resources','Man. Lauren Freeman','04/04/2019' );
insert into projects (id,name,dep_Name,supervisor,due_Date) values ( 7,'Monthly Sales Target','Sales','Man. Lauren Smith','18/04/2019' );


insert into DEPARTMENT_PROJECTS(department_id,projects_id) values (1,1);
insert into DEPARTMENT_PROJECTS(department_id,projects_id) values (2,2);
insert into DEPARTMENT_PROJECTS(department_id,projects_id) values (3,3);
insert into DEPARTMENT_PROJECTS(department_id,projects_id) values (2,4);
insert into DEPARTMENT_PROJECTS(department_id,projects_id) values (4,5);
insert into DEPARTMENT_PROJECTS(department_id,projects_id) values (5,6);
insert into DEPARTMENT_PROJECTS(department_id,projects_id) values (6,7);
