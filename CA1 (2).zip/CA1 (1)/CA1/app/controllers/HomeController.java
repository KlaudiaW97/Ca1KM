package controllers;

import play.mvc.*;

import views.html.*;

import play.api.Environment;
import play.data.*;
import play.db.ebean.Transactional;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

import models.*;
import models.users.*;
import models.products.*;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    private FormFactory formFactory;

    @Inject
    public HomeController(FormFactory f) {
        this.formFactory = f;
}
    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    public Result depAndProj(Long dep) {
        List<Projects> projectList = null;
        List<Department> departmentList = Department.findAll();

        if(dep ==0){
            projectList = Projects.findAll();
        }else {
            projectList = Department.find.ref(dep).getProjects();
        }
        return ok(depAndProj.render(projectList, departmentList,User.getUserById(session().get("email"))));

     }

    public Result index() {
        return ok(index.render(User.getUserById(session().get("email"))));
    }

    public Result contactUs() {
        return ok(contactUs.render(User.getUserById(session().get("email"))));
    }
    @Security.Authenticated(Secured.class)
    public Result addProject() {
        Form<Projects> projectForm = formFactory.form(Projects.class);
        return ok(addProject.render(projectForm,User.getUserById(session().get("email"))));
}
@Security.Authenticated(Secured.class)
@Transactional
public Result addProjectSubmit() {
    Form<Projects> newProjectForm = formFactory.form(Projects.class).bindFromRequest();

    if (newProjectForm.hasErrors()) {
        return badRequest(addProject.render(newProjectForm,User.getUserById(session().get("email"))));
    } else {
        Projects newProject = newProjectForm.get();

        List<Department> newDeps = new ArrayList<Department>();
        for (Long dep : newProject.getDepSelect()) {
            newDeps.add(Department.find.byId(dep));
        }
        newProject.setDepartments (newDeps);
        
        if(newProject.getId()==null){
        newProject.save();
        }else{
            newProject.update();
        }
        flash("success", "Project " + newProject.getName() + " was added/updated.");
        return redirect(controllers.routes.HomeController.depAndProj(0));
    }
}
@Security.Authenticated(Secured.class)
@Transactional
@With(AuthAdmin.class)
public Result deleteProject(Long id) {

    // The following line of code finds the item object by id, then calls the delete() method
    // on it to have it removed from the database.
    Projects.find.ref(id).delete();

    // Now write to the flash scope, as we did for the successful item creation.
    flash("success", "Project has been deleted.");
    // And redirect to the depAndProj page
    return redirect(controllers.routes.HomeController.depAndProj(0));
}
@Security.Authenticated(Secured.class)
public Result updateProject(Long id) {
    Projects i;
    Form<Projects> projectForm;

    try {
        // Find the project by id
        i = Projects.find.byId(id);

        // Populate the form object with data from the item found in the database
        projectForm = formFactory.form(Projects.class).fill(i);
    } catch (Exception ex) {
        return badRequest("error");
    }

    // Display the "add item" page, to allow the user to update the item
    return ok(addProject.render(projectForm,User.getUserById(session().get("email"))));
}
@Security.Authenticated(Secured.class)
@Transactional
@With(AuthAdmin.class)
public Result deleteAdmin(String email) {

    // The following line of code finds the item object by id, then calls the delete() method
    // on it to have it removed from the database.

    Manager u = (Manager) User.getUserById(email);
    u.delete();

    // Now write to the flash scope, as we did for the successful item creation.
    flash("success", "User has been deleted.");
    // And redirect to the depAndProj page
    return redirect(controllers.routes.HomeController.usersAdmin());
}
@Security.Authenticated(Secured.class)
public Result updateAdmin(String email) {
    Manager u;
    Form<Manager> userForm;

    try {
        // Find the item by email
        u = (Manager)User.getUserById(email);
        u.update();

        // Populate the form object with data from the user found in the database
        userForm = formFactory.form(Manager.class).fill(u);
    } catch (Exception ex) {
        return badRequest("error");
    }

    // Display the "add item" page, to allow the user to update the item
    return ok(addAdmin.render(userForm,User.getUserById(session().get("email"))));
}

@Security.Authenticated(Secured.class)
public Result addAdmin() {
    Form<Manager> userForm = formFactory.form(Manager.class);
    return ok(addAdmin.render(userForm,User.getUserById(session().get("email"))));
}
@Security.Authenticated(Secured.class)
@Transactional
public Result addAdminSubmit() {
Form<Manager> newUserForm = formFactory.form(Manager.class).bindFromRequest();
if (newUserForm.hasErrors()) {
    
    return badRequest(addAdmin.render(newUserForm,User.getUserById(session().get("email"))));
} else {
    Manager newUser = newUserForm.get();
    System.out.println("Name: "+newUserForm.field("name").getValue().get());
    System.out.println("Email: "+newUserForm.field("email").getValue().get());
    System.out.println("Password: "+newUserForm.field("password").getValue().get());
    System.out.println("Role: "+newUserForm.field("role").getValue().get());
    
    if(User.getUserById(newUser.getEmail())==null){
        newUser.save();
    }else{
        newUser.update();
    }
    flash("success", "User " + newUser.getName() + " was added/updated.");
    return redirect(controllers.routes.HomeController.usersAdmin());
    }
}
@Security.Authenticated(Secured.class)
public Result addEmployee() {
    Form<Employee> eForm = formFactory.form(Employee.class);
    return ok(addEmployee.render(eForm,User.getUserById(session().get("email"))));
}
@Security.Authenticated(Secured.class)
@Transactional
public Result addEmployeeSubmit() {
Form<Employee> newUserForm = formFactory.form(Employee.class).bindFromRequest();
if (newUserForm.hasErrors()) {
    
    return badRequest(addEmployee.render(newUserForm,User.getUserById(session().get("email"))));
} else {
    Employee newUser = newUserForm.get();
    System.out.println("Name: "+newUserForm.field("name").getValue().get());
    System.out.println("Email: "+newUserForm.field("email").getValue().get());
    System.out.println("Password: "+newUserForm.field("password").getValue().get());
    System.out.println("Role: "+newUserForm.field("role").getValue().get());
    
    if(User.getUserById(newUser.getEmail())==null){
        newUser.save();
    }else{
        newUser.update();
    }
    flash("success", "User " + newUser.getName() + " was added/updated.");
    return redirect(controllers.routes.HomeController.usersEmployee());
    }
}
@Security.Authenticated(Secured.class)
@Transactional
@With(AuthAdmin.class)
public Result deleteEmployee(String email) {

    // The following line of code finds the item object by id, then calls the delete() method
    // on it to have it removed from the database.

    Employee u = (Employee) User.getUserById(email);
    u.delete();

    // Now write to the flash scope, as we did for the successful item creation.
    flash("success", "User has been deleted.");
    // And redirect to the depAndProj page
    return redirect(controllers.routes.HomeController.usersEmployee());
}
@Security.Authenticated(Secured.class)
public Result updateEmployee(String email) {
    Employee u;
    Form<Employee> userForm;

    try {
        // Find the item by email
        u = (Employee) User.getUserById(email);
        u.update();

        // Populate the form object with data from the user found in the database
        userForm = formFactory.form(Employee.class).fill(u);
    } catch (Exception ex) {
        return badRequest("error");
    }

    // Display the "add item" page, to allow the user to update the item
    return ok(addEmployee.render(userForm,User.getUserById(session().get("email"))));
}
public Result usersAdmin() {
    List<Manager> userList = null;

    userList = Manager.findAll();

    return ok(admin.render(userList,User.getUserById(session().get("email"))));

 }

 public Result usersEmployee() {
    List<Employee> eList = null;

    eList = Employee.findAll();

    return ok(employees.render(eList,User.getUserById(session().get("email"))));

 }

}
