package models.products;

import java.util.*;
import javax.persistence.*;
import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class Projects extends Model {

    // Properties
    @Id
    private Long id;
    @Constraints.Required
    private String name;
    @Constraints.Required
    private String depName;
    @Constraints.Required
    private String supervisor;
    @Constraints.Required
    private String dueDate;

    @ManyToMany(cascade=CascadeType.ALL, mappedBy = "projects")
    private List<Department> departments;

    private List<Long> depSelect = new ArrayList<Long>();

    // Default Constructor
    public Projects() {
    }

    // Constructor to initialise object
    public Projects(Long id, String name, String depName, String supervisor, String dueDate) {
        this.id = id;
        this.name = name;
        this.depName = depName;
        this.supervisor = supervisor;
        this.dueDate = dueDate;
    }

    public static final Finder<Long, Projects> find = new Finder<>(Projects.class);
			    
    public static final List<Projects> findAll() {
        return Projects.find.all();
    }

    // Accessor methods
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDepName() {
        return depName;
    }
    public void setDepName(String depName) {
        this.depName = depName;
    }
    public String getSupervisor() {
        return supervisor;
    }
    public void setSupervisor(String supervisor) {
        this.supervisor = supervisor;
    }
    public String getDueDate() {
        return dueDate;
    }
    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
}

public List<Department> getDepartments() {
    return departments;
}
public void setDepartments(List <Department> departments) {
    this.departments = departments;
}
public List<Long> getDepSelect() {
    return depSelect;
}
public void setDepSelect(List<Long> depSelect) {
    this.depSelect = depSelect;
}
}