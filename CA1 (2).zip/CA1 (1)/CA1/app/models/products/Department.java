package models.products;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

// Product entity managed by Ebean
@Entity
public class Department extends Model {

   // Fields
   // Annotate id as primary key
   @Id
   private Long id;

   @Constraints.Required
   private String name;

   // Department contains many products
   @ManyToMany(cascade=CascadeType.ALL)
   private List<Projects> projects;

   // Default constructor
   public  Department() {
   }
			    
   public  Department(Long id, String name, List<Projects> projects) {
      this.id = id;
      this.name = name;
      this.projects = projects;
   }
   public Long getId() {
    return id;
}

public void setId(Long id) {
    this.id = id;
}

public String getName() {
    return name;
}

public void setName(String name) {
    this.name = name;
}

public List<Projects> getProjects() {
    return projects;
}

public void setProjects (List<Projects> projects) {
    this.projects = projects;
}
   //Generic query helper for entity Computer with id Long
public static Finder<Long,Department> find = new Finder<Long,Department>(Department.class);

//Find all Products in the database
public static List<Department> findAll() {
   return Department.find.query().where().orderBy("name asc").findList();
}

public static Map<String,String> options() {
    LinkedHashMap<String,String> options = new LinkedHashMap();
 
    // Get all the categories from the database and add them to the options hash map
    for (Department d: Department.findAll()) {
       options.put(d.getId().toString(), d.getName());
    }
    return options;
 }
 public static boolean inDepartment(Long department, Long project) {
    return find.query().where().eq("projects.id", project)
                       .eq("id", department)
                       .findList().size() > 0;
}
}